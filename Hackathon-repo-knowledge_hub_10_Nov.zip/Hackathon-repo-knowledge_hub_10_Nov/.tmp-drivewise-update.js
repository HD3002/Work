const fs = require("fs");
const path = require("path");

const files = [
  "index.html",
  ...fs.readdirSync("pages")
    .filter(file => file.endsWith(".html"))
    .map(file => path.join("pages", file))
];

const topics = [
  {
    id: "speed",
    title: "Speed",
    icon: "route",
    description: "Choose a safe speed for the road, traffic, weather, and visibility.",
    articleTitle: "Speed: choosing a safe speed",
    articleBody: "Choose a speed within posted limits that also suits visibility, traffic, the road and weather. Reduce speed early when conditions worsen; a posted limit is not always a safe target. Leave enough space to react and avoid rushing.",
    questions: [
      ["What should guide your speed?", 1, ["The posted limit alone.", "The limit and the conditions around you.", "The speed of the car behind you."]],
      ["Visibility drops in heavy rain. What is safest?", 0, ["Slow down smoothly and increase your space.", "Follow the car ahead more closely.", "Accelerate to get through quickly."]],
      ["Why leave a safe following distance?", 2, ["To stop others merging.", "To keep traffic moving faster.", "To give yourself time and space to react."]],
      ["An unfamiliar road is winding. How should you drive?", 1, ["Match the fastest traffic.", "Choose a speed that lets you respond to the road.", "Focus only on the posted limit."]],
      ["When might you need to travel below the limit?", 0, ["When conditions make the limit unsafe.", "Never.", "Only when traffic is heavy."]]
    ]
  },
  {
    id: "acceleration",
    title: "Acceleration",
    icon: "sparkles",
    description: "Use smooth, measured acceleration for predictable, controlled driving.",
    articleTitle: "Acceleration: build speed smoothly",
    articleBody: "Accelerate progressively and keep a steady, controlled pace. Smooth inputs help maintain traction and make your intentions easier for other road users to anticipate. Avoid sharp acceleration, especially on slippery roads or when visibility is limited.",
    questions: [
      ["What is a good acceleration habit?", 0, ["Build speed smoothly and progressively.", "Press the accelerator sharply.", "Accelerate hard into bends."]],
      ["Why use smooth controls on a slippery road?", 2, ["They raise the speed limit.", "They remove the need for space.", "They reduce sudden changes that can affect control."]],
      ["Traffic ahead is slowing. What should you do?", 1, ["Accelerate to close the gap.", "Ease off early and adjust smoothly.", "Keep accelerating until close."]],
      ["When should you avoid sudden acceleration?", 0, ["When it could reduce control or surprise others.", "Only at night.", "Only on empty roads."]],
      ["How can smooth acceleration help others?", 2, ["It signals a lane change.", "It guarantees no braking.", "It makes your movement predictable."]]
    ]
  },
  {
    id: "braking",
    title: "Braking",
    icon: "shield",
    description: "Look ahead, leave room to stop, and brake early and progressively.",
    articleTitle: "Braking: leave room to stop",
    articleBody: "Look well ahead and maintain enough following distance to respond to changing traffic. Ease off and brake progressively when slowing down. Increase your space and reduce speed when the road is wet, visibility is poor, or traffic is unpredictable.",
    questions: [
      ["What helps prevent last-second braking?", 1, ["Follow more closely.", "Look further ahead and leave stopping space.", "Wait until traffic stops."]],
      ["Traffic is slowing ahead. What is safer?", 0, ["Ease off early and brake progressively.", "Accelerate toward it then brake sharply.", "Look away until the line clears."]],
      ["Why increase your gap on a wet road?", 2, ["To brake later.", "To make the road less slippery.", "You may need more time and distance to respond."]],
      ["As you approach a hazard, what should you do?", 1, ["Brake only when beside it.", "Reduce speed smoothly and leave room.", "Steer suddenly without checking."]],
      ["Why scan well ahead?", 0, ["To notice hazards and adjust earlier.", "To use a shorter following distance.", "To avoid ever stopping."]]
    ]
  },
  {
    id: "cornering",
    title: "Cornering",
    icon: "car",
    description: "Slow before a bend, look through it, and steer with steady inputs.",
    articleTitle: "Cornering: stay smooth through bends",
    articleBody: "Check the road and reduce speed before entering a bend. Look toward the path you want to take and steer smoothly. Avoid abrupt braking, acceleration or steering mid-corner, and leave extra room when the surface or visibility is uncertain.",
    questions: [
      ["When should you reduce speed for a bend?", 0, ["Before entering, while you can adjust smoothly.", "In the middle of the bend.", "After accelerating out."]],
      ["Where should you direct your attention?", 2, ["At the dashboard.", "Only at the nearest road edge.", "Along your intended path, scanning for hazards."]],
      ["What is safer steering through a bend?", 1, ["Sharp last-second movements.", "Smooth, measured adjustments.", "Repeated sudden direction changes."]],
      ["The bend is wet or uneven. What should you do?", 0, ["Approach cautiously and avoid abrupt inputs.", "Accelerate hard through it.", "Follow another vehicle closely."]],
      ["Why avoid sudden braking mid-corner?", 2, ["It improves visibility.", "It shortens the bend.", "Abrupt inputs can unsettle the vehicle."]]
    ]
  },
  {
    id: "phone-use",
    title: "Phone Use",
    icon: "notepad",
    description: "Set up before you move; keep your attention on driving, not your screen.",
    articleTitle: "Phone use: keep your attention on driving",
    articleBody: "Set navigation and audio before setting off, and put your phone somewhere it will not distract you. Do not read, type or handle a phone while driving. If you need to use it, stop in a safe and lawful place first. Follow local road rules and vehicle guidance.",
    questions: [
      ["You need navigation. What is best?", 1, ["Enter the destination while moving.", "Set it up before driving; do not handle it on the road.", "Check the screen while driving."]],
      ["A message arrives while driving. What should you do?", 0, ["Wait until safely stopped to check it.", "Read it at a red light.", "Hold it low while driving."]],
      ["You need to change your route. What is safest?", 2, ["Reach for the phone while moving.", "Hold it in front of your view.", "Stop in a safe, lawful place first."]],
      ["How can you reduce phone distraction?", 1, ["Keep alerts on and check them in traffic.", "Set navigation, then place the phone out of reach.", "Hold the phone ready to respond."]],
      ["A call distracts you. What should you do?", 0, ["Focus on driving and deal with it only when safely stopped.", "Check the screen briefly.", "Speed up to finish sooner."]]
    ]
  }
];

function getActiveDriveWiseQuiz() {
  return DRIVEWISE_QUIZZES.find(quiz => quiz.id === activeDriveWiseTopicId) || DRIVEWISE_QUIZZES[0];
}

function startDriveWiseQuiz(topicId) {
  if (!DRIVEWISE_QUIZZES.some(quiz => quiz.id === topicId)) {
    console.warn("Unable to start an unknown DriveWise quiz.", topicId);
    return;
  }
  activeDriveWiseTopicId = topicId;
  renderQuizQuestions();
  navigate("module");
}

function startDriveWiseQuizByIndex(index) {
  const quiz = DRIVEWISE_QUIZZES[index];
  if (!quiz) {
    console.warn("Unable to start an unknown DriveWise quiz index.", index);
    return;
  }
  startDriveWiseQuiz(quiz.id);
}

function getDriveWiseBadgeInfo(topicId, now = new Date()) {
  const earnedAt = state.driveWiseBadges?.[topicId];
  if (!earnedAt) return { earned: false, expired: false, dueDate: null, earnedAt: null };
  const earnedDate = new Date(earnedAt);
  if (Number.isNaN(earnedDate.getTime())) {
    console.warn("Unable to read a saved DriveWise badge date.", topicId);
    return { earned: true, expired: true, dueDate: null, earnedAt: null, invalidDate: true };
  }
  const dueDate = addCalendarMonths(earnedDate, 12);
  return { earned: true, expired: now >= dueDate, dueDate, earnedAt: earnedDate };
}

function renderDriveWiseBadges() {
  document.querySelectorAll("[data-drivewise-badges]").forEach(host => {
    host.innerHTML = DRIVEWISE_QUIZZES.map((quiz, index) => {
      const badge = getDriveWiseBadgeInfo(quiz.id);
      const status = !badge.earned ? "NOT EARNED" : badge.expired ? "RE-EARN" : "EARNED";
      const buttonText = !badge.earned ? "Take quiz" : badge.expired ? "Re-earn badge" : "Retake quiz";
      const stateClass = badge.earned && !badge.expired ? " is-earned" : badge.expired ? " is-expired" : "";
      return [
        `<article class="drivewise-badge-card${stateClass}" data-topic="${quiz.id}">`,
        `<div class="drivewise-badge-top"><span class="drivewise-badge-icon">${iconSvg(quiz.icon)}</span><span class="drivewise-badge-status" data-badge-status>${status}</span></div>`,
        `<h3>${escapeHtml(quiz.title)}</h3>`,
        `<p class="drivewise-badge-description">${escapeHtml(quiz.description)}</p>`,
        `<p class="drivewise-badge-timer" data-badge-timer data-topic="${quiz.id}"></p>`,
        `<button class="button drivewise-badge-action" type="button" onclick="startDriveWiseQuizByIndex(${index})">${buttonText}</button>`,
        "</article>"
      ].join("");
    }).join("");
  });
  updateDriveWiseBadgeTimers();
  const activeCount = DRIVEWISE_QUIZZES.filter(quiz => {
    const badge = getDriveWiseBadgeInfo(quiz.id);
    return badge.earned && !badge.expired;
  }).length;
  document.querySelectorAll("[data-drivewise-badge-count]").forEach(el => {
    el.textContent = `${activeCount} of ${DRIVEWISE_QUIZZES.length} active`;
  });
}

function updateDriveWiseBadgeTimers(now = new Date()) {
  document.querySelectorAll("[data-badge-timer][data-topic]").forEach(timer => {
    const quiz = DRIVEWISE_QUIZZES.find(item => item.id === timer.dataset.topic);
    if (!quiz) return;
    const badge = getDriveWiseBadgeInfo(quiz.id, now);
    const status = timer.closest(".drivewise-badge-card")?.querySelector("[data-badge-status]");
    if (!badge.earned) {
      timer.textContent = "Complete this quiz to earn the badge";
      if (status) status.textContent = "NOT EARNED";
      return;
    }
    if (badge.invalidDate) {
      timer.textContent = "Renewal date unavailable - retake to refresh";
      if (status) status.textContent = "RE-EARN";
      return;
    }
    if (badge.expired) {
      timer.textContent = "Ready to re-earn - expired";
      if (status) status.textContent = "RE-EARN";
      return;
    }
    timer.textContent = `Re-earns in ${formatRemainingCountdown(badge.dueDate, now)}`;
    if (status) status.textContent = "EARNED";
  });
}

function renderQuizQuestions() {
  const quiz = getActiveDriveWiseQuiz();
  const correctPositions = [0, 1, 2, 0, 1];
  for (let i = correctPositions.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [correctPositions[i], correctPositions[j]] = [correctPositions[j], correctPositions[i]];
  }
  document.getElementById("quizQuestions").innerHTML = quiz.questions.map(([prompt, correct, options], index) => {
    const answers = options.map((text, option) => ({ text, correct: option === correct }));
    const target = correctPositions[index];
    const current = answers.findIndex(answer => answer.correct);
    [answers[target], answers[current]] = [answers[current], answers[target]];
    const answerHtml = answers.map(({ text, correct: isCorrect }) =>
      `<label><input type="radio" name="q${index + 1}" value="${isCorrect ? "correct" : "wrong"}">${escapeHtml(text)}</label>`
    ).join("");
    return `<div class="module-question"><h3>${index + 1} - ${escapeHtml(prompt)}</h3>${answerHtml}</div>`;
  }).join("");
}

function prepareTrainingModule() {
  const quiz = getActiveDriveWiseQuiz();
  document.getElementById("moduleTitle").textContent = `${quiz.title} Quiz`;
  document.getElementById("moduleTopicTitle").textContent = quiz.title;
  document.getElementById("moduleDescription").textContent =
    `Five questions on ${quiz.title.toLowerCase()}. Answer all five correctly to earn your DriveWise badge.`;
  document.getElementById("moduleTopicDescription").textContent = quiz.description;
  document.getElementById("submitTrainingButton").textContent = `Submit ${quiz.title.toLowerCase()} quiz`;
  renderQuizQuestions();
}

function completeTraining() {
  const quiz = getActiveDriveWiseQuiz();
  const answers = quiz.questions.map((_, index) =>
    document.querySelector(`input[name="q${index + 1}"]:checked`)
  );
  if (answers.some(answer => !answer)) {
    alert(`Please answer all five ${quiz.title.toLowerCase()} quiz questions.`);
    return;
  }
  if (answers.some(answer => answer.value !== "correct")) {
    showQuizRetry();
    return;
  }
  state.driveWiseBadges[quiz.id] = new Date().toISOString();
  saveState();
  document.querySelectorAll("#quizQuestions input[type=radio]").forEach(input => input.checked = false);
  document.getElementById("completionTitle").textContent = `${quiz.title} badge earned!`;
  document.getElementById("completionMessage").textContent =
    `You answered all five ${quiz.title.toLowerCase()} questions correctly. Your ${quiz.title} badge is active for 12 months.`;
  updateUI();
  const badge = getDriveWiseBadgeInfo(quiz.id);
  document.getElementById("completionDate").textContent = formatDate(badge.earnedAt);
  document.getElementById("completionDueDate").textContent = formatDate(badge.dueDate);
  navigate("completion");
  celebrateBadgeUnlock();
}

function replaceFunction(script, name, nextName, replacement, file) {
  const start = script.indexOf(`function ${name}(`);
  const end = script.indexOf(`\nfunction ${nextName}(`, start);
  if (start < 0 || end < 0) throw new Error(`${file}: cannot locate ${name}()`);
  return script.slice(0, start) + replacement.toString() + script.slice(end + 1);
}

const updates = [];
for (const file of files) {
  let html = fs.readFileSync(file, "utf8");
  const oldQuiz = html.match(/const QUIZ_QUESTIONS = \[[\s\S]*?\];/);
  if (!oldQuiz) throw new Error(`${file}: missing existing quiz data`);

  const topicCode = [
    `const DRIVEWISE_QUIZZES = ${JSON.stringify(topics)};`,
    "DRIVEWISE_QUIZZES.forEach(({ articleTitle, articleBody }) => ROLLIN_FAQS.push({ title: articleTitle, body: articleBody }));",
    "let activeDriveWiseTopicId = DRIVEWISE_QUIZZES[0].id;"
  ].join("\n");
  html = html.replace(oldQuiz[0], topicCode);

  let scriptStart = html.indexOf("<script>");
  let scriptEnd = html.lastIndexOf("</script>");
  let script = html.slice(scriptStart + 8, scriptEnd).replace(/\r\n/g, "\n");
  script = replaceFunction(script, "renderQuizQuestions", "faqCategory", renderQuizQuestions, file);
  script = replaceFunction(script, "prepareTrainingModule", "showMessage", prepareTrainingModule, file);
  script = replaceFunction(script, "completeTraining", "celebrateBadgeUnlock", completeTraining, file);

  const categoryRule = 'if (/claim|privacy|data collected|share my data|use data collected|track where|personal information/.test(t)) return "claims";';
  if (!script.includes(categoryRule)) throw new Error(`${file}: missing article categorizer`);
  script = script.replace(categoryRule, `${categoryRule}\nif (/speed|acceleration|braking|cornering/.test(t)) return "driving";`);

  const helperAnchor = "let activeDriveWiseTopicId = DRIVEWISE_QUIZZES[0].id;";
  if (!script.includes(helperAnchor)) throw new Error(`${file}: topic data insertion failed`);
  const helpers = [
    getActiveDriveWiseQuiz,
    startDriveWiseQuiz,
    startDriveWiseQuizByIndex,
    getDriveWiseBadgeInfo,
    renderDriveWiseBadges,
    updateDriveWiseBadgeTimers
  ].map(fn => fn.toString()).join("\n\n");
  script = script.replace(helperAnchor, `${helperAnchor}\n${helpers}`);

  const updateStart = script.indexOf("function updateUI()");
  const updateEnd = script.indexOf("\nfunction resetDemoData()", updateStart);
  if (updateStart < 0 || updateEnd < 0) throw new Error(`${file}: missing updateUI()`);
  let update = script.slice(updateStart, updateEnd);
  update = update.slice(0, update.lastIndexOf("}")) + `
renderDriveWiseBadges();
const activeBadgeCount = DRIVEWISE_QUIZZES.filter(quiz => {
  const badge = getDriveWiseBadgeInfo(quiz.id);
  return badge.earned && !badge.expired;
}).length;
document.getElementById("homeTrainingStatus").textContent =
  activeBadgeCount + " of " + DRIVEWISE_QUIZZES.length + " DriveWise badges earned";
document.getElementById("navTrainingCheck").classList.toggle("show", activeBadgeCount > 0);
}`;
  script = script.slice(0, updateStart) + update + script.slice(updateEnd);

  const resetStart = script.indexOf("function resetDemoData()");
  const resetEnd = script.indexOf("\nfunction updateClock()", resetStart);
  if (resetStart < 0 || resetEnd < 0) throw new Error(`${file}: missing resetDemoData()`);
  let reset = script.slice(resetStart, resetEnd)
    .replace("Reset your saved RoadReady quiz result and cycle dates.", "Reset all five DriveWise badges and saved quiz progress.")
    .replace("This clears your saved RoadReady quiz result and cycle dates.", "This clears all five DriveWise badges and saved quiz progress.")
    .replace("state = { ...DEFAULT_STATE };", "state = { ...DEFAULT_STATE, driveWiseBadges: {} };")
    .replace("You can replay the user stories.", "You can earn each DriveWise badge again.");
  script = script.slice(0, resetStart) + reset + script.slice(resetEnd);

  const oldDefault = `const DEFAULT_STATE = {
initialCompletedAt: null,
refresherCompletedAt: null
};`;
  if (!script.includes(oldDefault)) throw new Error(`${file}: missing DEFAULT_STATE`);
  script = script.replace(oldDefault, `const DEFAULT_STATE = {
initialCompletedAt: null,
refresherCompletedAt: null,
driveWiseBadges: {}
};`);

  const loadStart = script.indexOf("function loadState()");
  const loadEnd = script.indexOf("\nfunction saveState()", loadStart);
  if (loadStart < 0 || loadEnd < 0) throw new Error(`${file}: missing loadState()`);
  const loadState = `function loadState() {
try {
const saved = localStorage.getItem(STORAGE_KEY);
const parsed = saved ? JSON.parse(saved) : {};
const driveWiseBadges = parsed.driveWiseBadges && typeof parsed.driveWiseBadges === "object" && !Array.isArray(parsed.driveWiseBadges) ? parsed.driveWiseBadges : {};
return { ...DEFAULT_STATE, ...parsed, driveWiseBadges };
} catch (error) {
console.warn("Unable to load saved DriveWise quiz progress.", error);
return { ...DEFAULT_STATE, driveWiseBadges: {} };
}
}`;
  script = script.slice(0, loadStart) + loadState + script.slice(loadEnd);

  const timerInterval = `updateRefresherCountdown(info);
if (info.completed !== previousBadgeActive)`;
  if (!script.includes(timerInterval)) throw new Error(`${file}: missing badge timer interval`);
  script = script.replace(timerInterval, `updateRefresherCountdown(info);
updateDriveWiseBadgeTimers();
if (info.completed !== previousBadgeActive)`);
  html = html.slice(0, scriptStart + 8) + script + html.slice(scriptEnd);

  const articleCount = (html.match(/29 ARTICLES/g) || []).length;
  if (articleCount !== 1) throw new Error(`${file}: expected one static article count, got ${articleCount}`);
  html = html.replace("29 ARTICLES", "34 ARTICLES");

  const hubStart = html.indexOf('<section class="page" id="knowledgeHub">');
  const hubEnd = html.indexOf("</section>", hubStart) + "</section>".length;
  if (hubStart < 0 || hubEnd < 10) throw new Error(`${file}: missing DriveWise article section`);
  let hub = html.slice(hubStart, hubEnd);
  const oldHeading = hub.match(/<div class="section-heading"><h2>[^<]*DriveWise Pop Quiz<\/h2><span class="knowledge-check-badge">OPTIONAL<\/span><\/div>/);
  if (!oldHeading) throw new Error(`${file}: missing original quiz card heading`);
  hub = hub.replace(oldHeading[0], `<div class="section-heading"><h2>Your DriveWise badges</h2><span class="status-pill" data-drivewise-badge-count>0 of 5 active</span></div><p>Earn a badge in each topic. The renewal timer is tracked separately on every badge.</p><div class="drivewise-badge-grid" data-drivewise-badges="hub"></div><div class="section-heading legacy-drivewise-quiz"><h2>DriveWise Pop Quiz</h2><span class="knowledge-check-badge">OPTIONAL</span></div>`);
  hub = hub.replace('<div class="hub-card">', '<div class="hub-card legacy-drivewise-quiz">');
  hub = hub.replace('<div class="badge-panel" id="hubBadgePanel">', '<div class="badge-panel legacy-drivewise-quiz" id="hubBadgePanel">');
  html = html.slice(0, hubStart) + hub + html.slice(hubEnd);

  const trainingMarkup = `<section class="page${html.match(/<section class="page active" id="training">/) ? " active" : ""}" id="training">
<button class="text-link" style="margin-bottom:18px" onclick="navigate('knowledgeHub')" aria-label="Back to DriveWise">← Back to DriveWise</button>
<div class="eyebrow">DRIVEWISE BADGES</div><h1>Choose a quiz</h1>
<p>Complete five questions in a topic to earn its badge. Each badge has its own 12-month renewal timer.</p>
<div class="drivewise-badge-grid" data-drivewise-badges="quizzes"></div>
<div class="legacy-training-state" hidden><span id="trainingStatusText"></span><span id="trainingBadge"></span><div id="trainingProgressArea"><div id="trainingProgress"></div><p id="trainingDescription"></p><button id="startTrainingButton" type="button"></button></div><div id="trainingCompletedArea"></div></div></section>`;
  const training = html.match(/<section class="page(?: active)?" id="training">[\s\S]*?<\/section>/);
  if (!training) throw new Error(`${file}: missing training page`);
  html = html.replace(training[0], trainingMarkup);

  const moduleMarkup = `<section class="page${html.match(/<section class="page active" id="module">/) ? " active" : ""}" id="module">
<button class="text-link" style="margin-bottom:18px" onclick="navigate('training')" aria-label="Back to DriveWise quizzes">← Back to quizzes</button>
<div class="eyebrow">DRIVEWISE BADGE QUIZ</div><h1 id="moduleTitle">Speed Quiz</h1>
<p id="moduleDescription">Answer all five questions correctly to earn this DriveWise badge.</p>
<div class="card drivewise-quiz-card"><span class="roadready-quiz-badge">5 QUESTIONS</span>
<h2 id="moduleTopicTitle" style="margin-top:16px">Speed</h2><p id="moduleTopicDescription"></p>
<div class="notice"><strong>How to earn this badge</strong>Choose one answer for each question. Answer all five correctly to earn the badge. Each badge has its own 12-month timer.</div>
<div id="quizQuestions"></div><button class="button" id="submitTrainingButton" onclick="completeTraining()">Submit quiz</button>
<button class="button secondary" type="button" onclick="navigate('training')">Choose another quiz</button></div></section>`;
  const module = html.match(/<section class="page(?: active)?" id="module">[\s\S]*?<\/section>/);
  if (!module) throw new Error(`${file}: missing quiz module`);
  html = html.replace(module[0], moduleMarkup);

  const oldPreferences = / <div class="card"> <h2>RoadReady preferences<\/h2>[\s\S]*?<p class="cycle-disclaimer">[^<]*<\/p> <\/div>/;
  if (!oldPreferences.test(html)) throw new Error(`${file}: missing RoadReady preferences`);
  const preferences = `<div class="card drivewise-collection-card"><h2>DriveWise badge collection</h2>
<p>Each badge renews on its own 12-month timer. Retake an expired quiz to re-earn that badge.</p>
<div class="drivewise-badge-grid" data-drivewise-badges="settings"></div>
<div class="legacy-training-state" hidden><span id="settingsTrainingStatus"></span><span id="settingsRefresherStatus"></span></div></div>`;
  html = html.replace(oldPreferences, ` ${preferences}`);

  for (const match of html.matchAll(/<script>([\s\S]*?)<\/script>/g)) new Function(match[1]);
  for (const marker of ['data-drivewise-badges="hub"', 'data-drivewise-badges="quizzes"', 'data-drivewise-badges="settings"']) {
    if (!html.includes(marker)) throw new Error(`${file}: missing ${marker}`);
  }
  updates.push([file, html]);
}

for (const [file, html] of updates) fs.writeFileSync(file, html, "utf8");

const cssFile = "css/styles.css";
let css = fs.readFileSync(cssFile, "utf8");
if (css.includes(".drivewise-badge-grid{")) throw new Error("Badge collection styles already exist");
css += `
.legacy-drivewise-quiz,.legacy-training-state{display:none!important}
.drivewise-badge-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:11px;margin:16px 0 22px}
.drivewise-badge-card{min-width:0;padding:14px 12px 12px;border:1px solid #2b3943;border-radius:20px;background:linear-gradient(155deg,#17232c,#0d151b);box-shadow:0 10px 24px #0002;display:flex;flex-direction:column;align-items:flex-start;transition:border-color .2s ease,transform .2s ease}
.drivewise-badge-card.is-earned{border-color:#b9a800;background:linear-gradient(155deg,#29280f,#11191c)}
.drivewise-badge-card.is-expired{border-color:#b3754b}
.drivewise-badge-top{width:100%;display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:9px}
.drivewise-badge-icon{width:42px;height:42px;display:grid;place-items:center;border:1px solid #66727a;border-radius:50%;background:#11191e;color:#a8b5bf;box-shadow:inset 0 0 0 3px #ffffff08}
.drivewise-badge-icon .ui-icon{width:22px;height:22px}
.is-earned .drivewise-badge-icon{border-color:#ffe500;background:#ffe500;color:#111;box-shadow:0 0 18px #ffe50030}
.drivewise-badge-status{font-size:8px;line-height:1.2;letter-spacing:.08em;font-weight:800;color:#a8b5bf;text-align:right}
.is-earned .drivewise-badge-status{color:#ffe500}.is-expired .drivewise-badge-status{color:#ffb27b}
.drivewise-badge-card h3{margin:0 0 5px;color:#f7fafc;font-size:15px;letter-spacing:-.02em}
.drivewise-badge-description{margin:0 0 10px;color:#a8b5bf;font-size:10px;line-height:1.45;min-height:43px}
.drivewise-badge-timer{margin:auto 0 10px;color:#d4dce0;font-size:9px;line-height:1.4;min-height:25px;font-variant-numeric:tabular-nums}
.drivewise-badge-action.button{width:100%;min-height:34px;margin-top:0;padding:8px 5px;font-size:10px}
.drivewise-collection-card>p{margin-bottom:12px}.drivewise-quiz-card .module-question{margin:16px 0}.drivewise-quiz-card .notice{margin:14px 0}
@media(max-width:350px){.drivewise-badge-grid{grid-template-columns:1fr}.drivewise-badge-description{min-height:0}}
html[data-theme="light"] .drivewise-badge-card{background:linear-gradient(155deg,#fff,#f1f3f4);border-color:#ccd2d5}
html[data-theme="light"] .drivewise-badge-card.is-earned{border-color:#b5a300;background:linear-gradient(155deg,#fffbe0,#fff)}
html[data-theme="light"] .drivewise-badge-card.is-expired{border-color:#c87942}
html[data-theme="light"] .drivewise-badge-card h3{color:#111}
html[data-theme="light"] .drivewise-badge-description,html[data-theme="light"] .drivewise-badge-timer{color:#4d5960}
html[data-theme="light"] .drivewise-badge-icon{background:#edf0f2;color:#43505a}
html[data-theme="light"] .drivewise-badge-card.is-earned .drivewise-badge-icon{background:#ffe500;color:#111}
`;
fs.writeFileSync(cssFile, css, "utf8");

const readme = fs.readFileSync("README.md", "utf8");
fs.writeFileSync("README.md", readme.replace("interactive DriveWise Pop Quiz", "five topic-based DriveWise quizzes with individual badges and renewal timers"), "utf8");
console.log(`Updated ${updates.length} app pages with five quizzes and per-badge renewal timers.`);
